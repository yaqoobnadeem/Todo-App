from django import forms
from .models import Detail_model

class DetailsForm(forms.ModelForm):
    class Meta:
        model = Detail_model
        fields = ['title', 'description'] 
