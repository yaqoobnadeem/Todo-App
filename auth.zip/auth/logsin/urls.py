from django.urls import path
from .views import Dashboard_view, UpdateDetail_View, DeleteDetail_view, Login_view, Signup_View, logout_view

urlpatterns = [
    path('', Login_view.as_view(), name='login'),
    path('dashboard/', Dashboard_view.as_view(), name='dashboard'),
    path('signup/', Signup_View.as_view(), name='signup'),
    path('detail/update/<int:detail_id>/', UpdateDetail_View.as_view(), name='update_detail'),
    path('detail/delete/<int:detail_id>/', DeleteDetail_view.as_view(), name='delete_detail'),
    path('logout/', logout_view, name='logout'),
]
