from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from .forms import DetailsForm
from .models import Detail_model 

class Dashboard_view(View):

    def get(self, request):
        if not request.user.is_authenticated:
            return redirect('login')

        user_details = Detail_model.objects.filter(user=request.user)
        form = DetailsForm()
        return render(request, 'dashboard.html', {'form': form, 'user_details': user_details})

    def post(self, request):
        if not request.user.is_authenticated:
            return redirect('login')

        form = DetailsForm(request.POST)
        if form.is_valid():
            detail = form.save(commit=False)
            detail.user = request.user
            detail.save()
            return redirect('dashboard')

        user_details = Detail_model.objects.filter(user=request.user)
        return render(request, 'dashboard.html', {'form': form, 'user_details': user_details})

class UpdateDetail_View(View):
    def get(self, request, detail_id):
        if not request.user.is_authenticated:
            return redirect('login')

        detail = get_object_or_404(Detail_model, id=detail_id, user=request.user)
        form = DetailsForm(instance=detail)
        
        return render(request, 'editdash.html', {'form': form, 'detail': detail})

    def post(self, request, detail_id):
        if not request.user.is_authenticated:
            return redirect('login')

        detail = get_object_or_404(Detail_model, id=detail_id, user=request.user)
        form = DetailsForm(request.POST, instance=detail)

        if form.is_valid():
            form.save()
            return redirect('dashboard')
        
        return render(request, 'editdash.html', {'form': form, 'detail': detail})

class DeleteDetail_view(View):
    def post(self, request, detail_id):
        if not request.user.is_authenticated:
            return redirect('login')

        detail = get_object_or_404(Detail_model, id=detail_id, user=request.user)
        detail.delete()
        return redirect('dashboard')

class Login_view(View):

    def get(self, request):
        return render(request, 'login.html')

    def post(self, request):
        uname = request.POST.get('username')
        passw = request.POST.get('password')
        user = authenticate(request, username=uname, password=passw)
        if user:
            login(request, user)
            return redirect('dashboard')
        else:
            messages.error(request, "Invalid username or password.")
            return render(request, 'login.html')

class Signup_View(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        username = request.POST.get('username')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        password = request.POST.get('password')
        password_check = request.POST.get('password_check')

        if password != password_check:
            messages.error(request, "Passwords do not match.")
            return render(request, 'signup.html')
        
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken.")
            return render(request, 'signup.html')
        
        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already registered.")
            return render(request, 'signup.html')
        
        user = User.objects.create_user(username=username, email=email, password=password)
        user.first_name = first_name
        user.last_name = last_name
        user.save()
        
        login(request, user)  
        return redirect('login')

def logout_view(request):
    logout(request)
    return redirect('login')
