from django.contrib import admin
from .models import Detail_model


admin.site.register(Detail_model)
